import java.io.File;
import java.util.Scanner;

public class MyFile {

	public MyFile() {
		// TODO Auto-generated constructor stub
	}

	//data need to save
		private static String fullpath;
		private String name;
		
		//Enter directories
		static Scanner sc = new Scanner(System.in);
		public String fileDirectory() {
			System.out.print("Enter a directory: ");
			String y = sc.nextLine();
			return y;
		}
		
		//Print file and directories
		public void readFile(String x){
			File folder = new File(x);
			File[] listOfFiles = folder.listFiles();
			for(int i = 0; i < listOfFiles.length; i++){
				if(listOfFiles[i].isFile()){
					long si = listOfFiles[i].length();
					name = listOfFiles[i].getName();
					System.out.printf("\t\t%-25s%15d\n",name,si);
				}else if(listOfFiles[i].isDirectory()){
				    readFile(listOfFiles[i].getPath());
				}
			}
		}
		
		//Sort file name in size: Selection Sort
		public void sortSize(String x){
			File f = new File(x);
			File[] listFiles = f.listFiles();
			
			for(int g = 0; g < listFiles.length; g++){
				for(int j = 1; j < listFiles.length; j++){
					File temp;
					if(listFiles[j-1].length() > listFiles[j].length()){
						temp = listFiles[j];
						listFiles[j] = listFiles[j-1];
						listFiles[j-1] = temp;
					}
				}
			}
			System.out.println("\t\t| Name    \t\t\t    |Size|");
			
			//print sorted file in size
			for(int i = 0; i < listFiles.length; i++){
				if(listFiles[i].isFile()){
					long size = listFiles[i].length();
					String nameFiles = listFiles[i].getName();
					System.out.printf("\t\t%-25s%15d\n",nameFiles,size);
				}else if(listFiles[i].isDirectory()){
				    readFile(listFiles[i].getPath());
				}
			}
		    
		}
		
		//Insertion sort
		public void insertionSort(String y){
			File fo = new File(y);
			File[] x = fo.listFiles();
			for(int f = 0; f < x.length; f++){
				File current = x[f];
				int j = f-1;
				while(j >= 0 && x[j].length() > current.length()){
					x[j+1] = x[j];
					j = j-1;
					x[j+1] = current;
				}
			}
			
             System.out.println("\t\t| Name    \t\t\t    |Size|");
			
			//print sorted file in size
			for(int n = 0; n < x.length; n++){
				if(x[n].isFile()){
					long ize = x[n].length();
					String name = x[n].getName();
					System.out.printf("\t\t%-25s%15d\n",name,ize);
				}else if(x[n].isDirectory()){
				    readFile(x[n].getPath());
				}
			}
		}
		
		//search file name
		public void searchName(String s){
			File fold = new File(s);
			File[] list = fold.listFiles();
			sc = new Scanner(System.in);
			System.out.print("Enter name of file: ");
			String search = sc.nextLine();
			for(int r = 0; r < list.length; r++){
				if(list[r].getName().contains(search)){
					System.out.println(list[r].getName());
				}
			}
		}
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			MyFile a = new MyFile();
			fullpath = a.fileDirectory();
			int menu = 0;
			do {
			do {
				try {
					System.out.println("\n--------menu--------");
	                System.out.println("1. View All File In Directory");
	                System.out.println("2. Sorted List in size: Selection Sort Algorithms");
	                System.out.println("3. Sorted List in size: Insertion Sort Algorithms");
	                System.out.println("4. Search file name");
	                System.out.print("Please choose: ");

	                sc = new Scanner(System.in);
	                menu = sc.nextInt();
	                break;
	                } catch (Exception e) {
	                    System.out.println("Please choose menu 1, 2, 3 or 4");
	                }
	            } while (true);

	            switch (menu) {
	            case 1:
	            	a.readFile(fullpath);
                    break;
                case 2:
                	System.out.println("Selection Sort Algorithms ");
        			a.sortSize(fullpath);
        			break;
                case 3:
                	System.out.println("Insertion sort Algorithms ");
        			a.insertionSort(fullpath);
        			break;
                case 4:
                	System.out.println("File Name: ");
        			a.searchName(fullpath);
        			break;
        		default:
        			System.out.println("Please enter 1, 2,3,4");
        			break;
	            }
			 } while (menu != 0);
			}
		
}
